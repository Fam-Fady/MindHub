import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const apiKey = String.fromEnvironment('FIREBASE_API_KEY');
  const appId = String.fromEnvironment('FIREBASE_APP_ID');
  const senderId = String.fromEnvironment('FIREBASE_MESSAGING_SENDER_ID');
  const projectId = String.fromEnvironment('FIREBASE_PROJECT_ID');
  if ([apiKey, appId, senderId, projectId].any((value) => value.isEmpty)) {
    runApp(const MaterialApp(home: Scaffold(body: Center(child: Padding(
      padding: EdgeInsets.all(24), child: Text(
        'MindHub Firebase is not configured. Add firebase build variables; see SETUP.md.',
        textAlign: TextAlign.center,
      ),
    )))));
    return;
  }
  await Firebase.initializeApp(options: FirebaseOptions(
    apiKey: apiKey,
    appId: appId,
    messagingSenderId: senderId,
    projectId: projectId,
    authDomain: const String.fromEnvironment('FIREBASE_AUTH_DOMAIN'),
    storageBucket: const String.fromEnvironment('FIREBASE_STORAGE_BUCKET'),
  ));
  runApp(const MindHub());
}

class MindHub extends StatelessWidget {
  const MindHub({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'MindHub', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff7459d7), brightness: Brightness.dark), useMaterial3: true),
    home: StreamBuilder<User?>(
      stream: FirebaseAuth.instance.userChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        return snapshot.data == null ? const AuthPage() : (snapshot.data!.emailVerified ? const HomePage() : const VerifyEmailPage());
      },
    ),
  );
}


String apiError(http.Response response, String operation) {
    String? code;
    try {
      final parsed = jsonDecode(response.body);
      if (parsed is Map) code = parsed['code']?.toString();
    } catch (_) {}
    if (response.statusCode == 401) return 'Session expired. Sign in again / انتهت الجلسة، سجّل الدخول مجددًا';
    if (response.statusCode == 429) return 'Too many requests. Please try again later / طلبات كثيرة، حاول لاحقًا';
    if (code == 'recent_login_required') return 'Please sign in again before deleting your account / سجّل الدخول مجددًا قبل الحذف';
    if (code == 'email_not_verified') return 'Verify your email address first / تحقق من بريدك الإلكتروني أولاً';
    if (response.statusCode >= 500) return 'Server temporarily unavailable. Try again later / الخادم غير متاح مؤقتًا';
    return '$operation failed (${response.statusCode}). Please try again / فشلت العملية، حاول مجددًا';
}

String userFacingError(Object error) {
  final raw = error.toString();
  return raw.replaceFirst(RegExp(r'^Exception: '), '');
}

class VerifyEmailPage extends StatefulWidget {
  const VerifyEmailPage({super.key});
  @override State<VerifyEmailPage> createState() => _VerifyEmailPageState();
}
class _VerifyEmailPageState extends State<VerifyEmailPage> {
  String status = '';
  Future<void> refresh() async {
    try { await FirebaseAuth.instance.currentUser!.reload(); await FirebaseAuth.instance.currentUser!.getIdToken(true); setState(() => status = 'Verification status refreshed'); }
    catch (e) { setState(() => status = userFacingError(e)); }
  }
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: ConstrainedBox(
    constraints: const BoxConstraints(maxWidth: 430), child: SingleChildScrollView(padding: const EdgeInsets.all(24),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.mark_email_unread_outlined, size: 58),
      const SizedBox(height: 14),
      const Text('Verify your email / تحقق من بريدك الإلكتروني', textAlign: TextAlign.center),
      const SizedBox(height: 12),
      Text(FirebaseAuth.instance.currentUser?.email ?? ''),
      FilledButton(onPressed: refresh, child: const Text('I verified my email / تحققت من البريد')),
      TextButton(onPressed: () async {
        try { await FirebaseAuth.instance.currentUser!.sendEmailVerification(); setState(() => status = 'Verification email sent'); }
        catch (e) { setState(() => status = userFacingError(e)); }
      }, child: const Text('Resend verification email')),
      TextButton(onPressed: () async {
        const base = String.fromEnvironment('MINDHUB_API_BASE_URL');
        if (base.isEmpty) { setState(() => status = 'Configure the API URL to export account data.'); return; }
        try {
          final token = await FirebaseAuth.instance.currentUser!.getIdToken(true);
          final response = await http.get(Uri.parse('$base/v1/me/export'), headers: {'Authorization': 'Bearer $token'});
          if (response.statusCode != 200) throw Exception(apiError(response, 'Export'));
          if (!mounted) return;
          await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
            title: const Text('My data / بياناتي'), content: SingleChildScrollView(child: SelectableText(response.body)),
            actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))]));
        } catch (e) { if (mounted) setState(() => status = userFacingError(e)); }
      }, child: const Text('View/export my data / عرض بياناتي')),
      TextButton(onPressed: () async {
        const base = String.fromEnvironment('MINDHUB_API_BASE_URL');
        if (base.isEmpty) { setState(() => status = 'Configure the API URL before deleting.'); return; }
        final password = TextEditingController();
        final secret = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
          title: const Text('Delete account permanently? / حذف الحساب نهائياً؟'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('This deletes account and saved cloud data. This cannot be undone.'),
            TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Current password'))]),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, password.text), child: const Text('Delete permanently'))]));
        password.dispose();
        if (secret == null || secret.isEmpty) return;
        try {
          final u = FirebaseAuth.instance.currentUser!;
          await u.reauthenticateWithCredential(EmailAuthProvider.credential(email: u.email!, password: secret));
          final token = await u.getIdToken(true);
          final response = await http.delete(Uri.parse('$base/v1/me'), headers: {'Authorization': 'Bearer $token'});
          if (response.statusCode != 200) throw Exception(apiError(response, 'Account deletion'));
          await FirebaseAuth.instance.signOut();
        } catch (e) { if (mounted) setState(() => status = userFacingError(e)); }
      }, child: const Text('Delete my account / حذف الحساب')),
      TextButton(onPressed: () => FirebaseAuth.instance.signOut(), child: const Text('Sign out')),
      Text(status),
    ])))));
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override State<AuthPage> createState() => _AuthPageState();
}
class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  final name = TextEditingController();
  bool register = false, busy = false;
  String? error;
  @override void dispose() { email.dispose(); password.dispose(); name.dispose(); super.dispose(); }
  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      if (register) {
        final displayName = name.text.trim();
        if (displayName.isEmpty || displayName.runes.length > 80) {
          setState(() => error = 'Display name must be 1–80 characters / يجب أن يكون الاسم من ١ إلى ٨٠ حرفًا');
          return;
        }
        final result = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.text.trim(), password: password.text);
        await result.user!.updateDisplayName(displayName);
        await result.user!.sendEmailVerification();
        await FirebaseFirestore.instance.collection('users').doc(result.user!.uid).set({
          'displayName': displayName, 'email': result.user!.email,
          'language': 'en', 'createdAt': FieldValue.serverTimestamp(),
        });
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
      }
    } on FirebaseAuthException catch (e) { if (mounted) setState(() => error = e.message ?? e.code); }
      catch (e) { if (mounted) setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> reset() async {
    if (email.text.trim().isEmpty) { setState(() => error = 'Enter your email first / أدخل بريدك الإلكتروني أولاً'); return; }
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email.text.trim());
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('If the address is registered, check your email.')));
    } on FirebaseAuthException catch (e) { if (mounted) setState(() => error = e.message); }
  }
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: SingleChildScrollView(child: ConstrainedBox(
    constraints: const BoxConstraints(maxWidth: 430),
    child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.hub, size: 68, color: Color(0xffad8aff)),
      const SizedBox(height: 12), const Text('MindHub | مايند هب', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
      const SizedBox(height: 24),
      if (register) TextField(controller: name, decoration: const InputDecoration(labelText: 'Display name / الاسم')),
      TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email / البريد الإلكتروني')),
      TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password / كلمة المرور')),
      if (error != null) Padding(padding: const EdgeInsets.all(12), child: Text(error!, style: const TextStyle(color: Colors.redAccent))),
      const SizedBox(height: 20),
      FilledButton(onPressed: busy ? null : submit, child: Text(register ? 'Create account / إنشاء حساب' : 'Sign in / تسجيل الدخول')),
      TextButton(onPressed: busy ? null : () => setState(() { register = !register; error = null; }), child: Text(register ? 'Already have an account? Sign in' : 'New user? Create account')),
      TextButton(onPressed: busy ? null : reset, child: const Text('Forgot password? / نسيت كلمة المرور؟')),
    ])),
  ))));
}

class MiniApp {
  const MiniApp(this.id, this.en, this.ar, this.descEn, this.descAr);
  final String id, en, ar, descEn, descAr;
  String label(bool arabic) => arabic ? ar : en;
  String description(bool arabic) => arabic ? descAr : descEn;
}
const allApps = <MiniApp>[
  MiniApp('codroutine', 'CodeRoutine', 'كود روتين', 'Coding studio', 'استوديو البرمجة'),
  MiniApp('floweasy', 'FlowEasy', 'فلو إيزي', 'Life organizer', 'منظم الحياة'),
  MiniApp('forma3d', 'Forma3D', 'فورما 3D', 'Room planner', 'مخطط الغرف'),
  MiniApp('labyrinth', 'Labyrinth', 'لابيرينث', 'Logic circuits', 'الدوائر المنطقية'),
  MiniApp('lingua', 'Lingua', 'لينجوا', 'Language learning', 'تعلم اللغات'),
  MiniApp('mindecho', 'MindEcho', 'مايند إيكو', 'Habits and routines', 'العادات والروتين'),
  MiniApp('mindmoney', 'MindMoney', 'مايند موني', 'Budget and expenses', 'الميزانية والمصروفات'),
  MiniApp('mindvault', 'MindVault', 'مايند فولت', 'Notes and documents', 'الملاحظات والمستندات'),
  MiniApp('mindwell', 'MindWell', 'مايند ويل', 'Wellness tracker', 'متابعة الصحة'),
  MiniApp('minihub', 'MiniHub', 'ميني هب', 'Everyday tools', 'أدوات يومية'),
  MiniApp('offline-toolkit', 'Offline Toolkit', 'أدوات بلا إنترنت', 'Offline utilities', 'أدوات بدون إنترنت'),
  MiniApp('pathora', 'Pathora', 'باثورا', 'Career planning', 'التخطيط المهني'),
  MiniApp('pixelforge', 'PixelForge', 'بكسل فورج', 'Pixel game maker', 'صناعة ألعاب البكسل'),
  MiniApp('plant_doctor', 'Plant Doctor', 'طبيب النباتات', 'Plant care', 'العناية بالنباتات'),
  MiniApp('playlab', 'PlayLab', 'بلاي لاب', 'Creative playground', 'مساحة إبداعية'),
  MiniApp('playworld', 'PlayWorld', 'عالم اللعب', 'Community games', 'ألعاب المجتمع'),
  MiniApp('quillix', 'Quillix', 'كويليكس', 'Writing assistant', 'مساعد الكتابة'),
  MiniApp('roamly', 'Roamly', 'روملي', 'Travel planner', 'مخطط السفر'),
  MiniApp('synaptix', 'Synaptix', 'سينابتكس', 'AI workspace', 'مساحة الذكاء الاصطناعي'),
  MiniApp('terranest', 'TerraNest', 'تيرانست', 'Sustainability', 'الاستدامة'),
  MiniApp('vendora', 'Vendora', 'فندورا', 'Small business', 'إدارة الأعمال'),
  MiniApp('veyra', 'Veyra', 'فيرا', 'Creative briefs', 'الأفكار الإبداعية'),
  MiniApp('voxora', 'Voxora', 'فوكسورا', 'Meeting notes', 'ملاحظات الاجتماعات'),
];

const appColors = [Color(0xffb39aff), Color(0xff52cee0), Color(0xffffb66e), Color(0xff8fda9a), Color(0xfff29cca)];
const appIcons = [Icons.code, Icons.calendar_month, Icons.view_in_ar, Icons.account_tree, Icons.translate,
  Icons.track_changes, Icons.payments, Icons.lock_outline, Icons.spa, Icons.widgets, Icons.offline_bolt,
  Icons.route, Icons.grid_on, Icons.local_florist, Icons.palette, Icons.sports_esports, Icons.edit_note,
  Icons.flight, Icons.psychology, Icons.eco, Icons.storefront, Icons.lightbulb, Icons.mic];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  final search = TextEditingController();
  bool arabic = false;
  bool tiles = true;
  @override void initState() { super.initState(); readLanguage(); }
  Future<void> readLanguage() async {
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      final snap = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      if (mounted) setState(() => arabic = snap.data()?['language'] == 'ar');
    } catch (_) { /* Profile remains usable when Firestore is temporarily offline. */ }
  }
  Future<void> setLanguage(bool value) async {
    setState(() => arabic = value);
    try { await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).set({'language': value ? 'ar' : 'en', 'updatedAt': FieldValue.serverTimestamp()}, SetOptions(merge: true)); }
    catch (_) { /* Keep local UI responsive; user can retry in Account. */ }
  }
  void openApp(MiniApp app) => Navigator.push(context,
    MaterialPageRoute(builder: (_) => MiniAppPage(app: app, arabic: arabic)));
  @override void dispose() { search.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    final query = search.text.trim().toLowerCase();
    final filtered = allApps.where((a) => '${a.en} ${a.ar} ${a.descEn} ${a.descAr}'.toLowerCase().contains(query)).toList();
    return Directionality(textDirection: arabic ? TextDirection.rtl : TextDirection.ltr, child: Scaffold(
      appBar: AppBar(title: const Text('✦ MindHub'), actions: [
        IconButton(tooltip: arabic ? 'عرض القائمة' : 'Toggle layout', icon: Icon(tiles ? Icons.view_list_rounded : Icons.grid_view_rounded), onPressed: () => setState(() => tiles = !tiles)),
        TextButton(onPressed: () => setLanguage(!arabic), child: Text(arabic ? 'English' : 'العربية')),
        IconButton(tooltip: arabic ? 'الحساب' : 'Account', icon: const Icon(Icons.manage_accounts), onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AccountPage()));
          readLanguage();
        }),
      ]),
      body: LayoutBuilder(builder: (context, constraints) {
        final count = constraints.maxWidth >= 1050 ? 4 : constraints.maxWidth >= 680 ? 3 : constraints.maxWidth >= 410 ? 2 : 1;
        return ListView(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18), children: [
          Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xff393080), Color(0xff6752ba), Color(0xff176d91)]),
            borderRadius: BorderRadius.circular(24)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.auto_awesome, size: 30, color: Colors.white),
              const SizedBox(height: 10),
              Text(arabic ? 'مرحباً بك في MindHub' : 'Welcome to MindHub', style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
              const SizedBox(height: 7),
              Text(arabic ? 'كل أدواتك في مكان واحد • ويب و Flutter' : 'Your creative universe • Flutter + HTML together', style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 14),
              Chip(avatar: const Icon(Icons.apps, size: 17), label: Text(arabic ? '٢٣ تطبيقاً' : '23 connected mini-apps')),
            ])),
          const SizedBox(height: 22),
          TextField(controller: search, onChanged: (_) => setState(() {}), decoration: InputDecoration(
            filled: true, prefixIcon: const Icon(Icons.search), hintText: arabic ? 'ابحث في التطبيقات...' : 'Find an app or tool...',
            suffixIcon: query.isEmpty ? null : IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() => search.clear())),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
          const SizedBox(height: 18),
          Row(children: [Expanded(child: Text(arabic ? 'استكشف التطبيقات' : 'Explore apps', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))),
            Text('${filtered.length} / ${allApps.length}', style: Theme.of(context).textTheme.labelLarge)]),
          const SizedBox(height: 12),
          if (filtered.isEmpty) Padding(padding: const EdgeInsets.all(34), child: Center(child: Text(arabic ? 'لا توجد نتائج' : 'No matching apps')))
          else if (tiles) GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: count,
              childAspectRatio: count == 1 ? 2.9 : count == 2 ? 1.18 : 1.5, crossAxisSpacing: 12, mainAxisSpacing: 12),
            itemCount: filtered.length, itemBuilder: (context, i) {
              final app = filtered[i]; final color = appColors[allApps.indexOf(app) % appColors.length];
              return Card(clipBehavior: Clip.antiAlias, child: InkWell(onTap: () => openApp(app),
                child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Container(padding: const EdgeInsets.all(9), decoration: BoxDecoration(color: color.withValues(alpha: .16), borderRadius: BorderRadius.circular(13)),
                    child: Icon(appIcons[allApps.indexOf(app) % appIcons.length], color: color, size: 27)),
                  const Spacer(),
                  Text(app.label(arabic), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16), maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 3),
                  Text(app.description(arabic), style: Theme.of(context).textTheme.bodySmall, maxLines: 2, overflow: TextOverflow.ellipsis),
                ]))));
            })
          else ...filtered.map((app) => Card(child: ListTile(
            leading: Icon(appIcons[allApps.indexOf(app) % appIcons.length], color: appColors[allApps.indexOf(app) % appColors.length]),
            title: Text(app.label(arabic)), subtitle: Text(app.description(arabic)),
            trailing: const Icon(Icons.chevron_right), onTap: () => openApp(app)))),
          const SizedBox(height: 30),
          Center(child: Text(arabic ? 'احتفظ بنسخة HTML الكاملة داخل كل تطبيق' : 'Open any app to switch between native workspace and original HTML',
            textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall)),
        ]);
      }),
    ));
  }
}

// Both modes are intentionally available per app: native Flutter workspace with
// per-user Firestore notes, and the complete original HTML interface in a WebView.
class MiniAppPage extends StatefulWidget {
  const MiniAppPage({super.key, required this.app, required this.arabic});
  final MiniApp app;
  final bool arabic;
  @override State<MiniAppPage> createState() => _MiniAppPageState();
}
class _MiniAppPageState extends State<MiniAppPage> {
  int tab = 0;
  InAppLocalhostServer? server;
  bool serverReady = false, serverFailed = false;
  @override void initState() { super.initState(); }
  Future<void> startServer() async {
    if (server != null) return;
    if (mounted) setState(() => serverFailed = false);
    final instance = InAppLocalhostServer(documentRoot: 'assets/web', port: 8087);
    try { await instance.start(); server = instance; if (mounted) setState(() => serverReady = true); }
    catch (_) { if (mounted) setState(() { serverReady = false; serverFailed = true; }); }
  }
  @override void dispose() { server?.close(); super.dispose(); }
  @override Widget build(BuildContext context) {
    final a = widget.arabic;
    return Directionality(textDirection: a ? TextDirection.rtl : TextDirection.ltr, child: Scaffold(
      appBar: AppBar(title: Text(widget.app.label(a))),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: SegmentedButton<int>(
          segments: [ButtonSegment(value: 0, icon: const Icon(Icons.phone_android), label: const Text('Flutter')),
            ButtonSegment(value: 1, icon: const Icon(Icons.language), label: const Text('HTML'))],
          selected: {tab}, onSelectionChanged: (selection) { setState(() => tab = selection.first); if (tab == 1) startServer(); })),
        Expanded(child: tab == 0 ? NativeWorkspace(app: widget.app, arabic: a) :
          serverReady ? InAppWebView(
            initialUrlRequest: URLRequest(url: WebUri('http://localhost:8087/apps/${widget.app.id}.html?lang=${a ? 'ar' : 'en'}')),
            initialSettings: InAppWebViewSettings(javaScriptEnabled: true, iframeAllowFullscreen: true, supportZoom: false)) :
          serverFailed ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(a ? 'تعذّر تشغيل الخادم المحلي. أعد المحاولة.' : 'Could not start the local HTML server. Please try again.', textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton(onPressed: startServer, child: Text(a ? 'إعادة المحاولة' : 'Retry'))]))) :
          const Center(child: CircularProgressIndicator())),
      ]),
    ));
  }
}

class NativeWorkspace extends StatefulWidget {
  const NativeWorkspace({super.key, required this.app, required this.arabic});
  final MiniApp app;
  final bool arabic;
  @override State<NativeWorkspace> createState() => _NativeWorkspaceState();
}
class _NativeWorkspaceState extends State<NativeWorkspace> {
  CollectionReference<Map<String, dynamic>> get items => FirebaseFirestore.instance
      .collection('users').doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('workspaces').doc(widget.app.id).collection('items');
  Future<void> editItem([QueryDocumentSnapshot<Map<String, dynamic>>? existing]) async {
    final a = widget.arabic;
    final title = TextEditingController(text: existing?.data()['title'] as String? ?? '');
    final details = TextEditingController(text: existing?.data()['details'] as String? ?? '');
    final result = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: Text(existing == null ? (a ? 'إضافة عنصر' : 'Add item') : (a ? 'تعديل العنصر' : 'Edit item')),
      content: SizedBox(width: 450, child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: title, maxLength: 120, decoration: InputDecoration(labelText: a ? 'العنوان' : 'Title')),
        TextField(controller: details, maxLines: 4, maxLength: 3000, decoration: InputDecoration(labelText: a ? 'التفاصيل' : 'Details')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: Text(a ? 'إلغاء' : 'Cancel')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(a ? 'حفظ' : 'Save'))],
    ));
    if (result == true && title.text.trim().isNotEmpty) {
      try {
        final data = {'title': title.text.trim(), 'details': details.text.trim(), 'updatedAt': FieldValue.serverTimestamp()};
        if (existing == null) { await items.add({...data, 'createdAt': FieldValue.serverTimestamp()}); }
        else { await existing.reference.update(data); }
      } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(userFacingError(e)))); }
    }
    title.dispose(); details.dispose();
  }
  @override Widget build(BuildContext context) {
    final a = widget.arabic;
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(onPressed: () => editItem(),
        icon: const Icon(Icons.add), label: Text(a ? 'إضافة' : 'Add item')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 10, 16, 100), children: [
        Text(widget.app.label(a), style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 5), Text(widget.app.description(a)),
        const SizedBox(height: 12),
        Text(a ? 'مساحة Flutter أصلية لحفظ العناصر والملاحظات الخاصة بهذا التطبيق في حسابك. الأدوات الكاملة موجودة في تبويب HTML.' :
          'Native Flutter workspace for app-specific items and notes, saved to your account. For the original full set of tools, select HTML.',
          style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 16),
        StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: items.orderBy('updatedAt', descending: true).snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasError) return Text('${a ? 'خطأ' : 'Error'}: ${snapshot.error}');
            if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
            final entries = snapshot.data!.docs;
            if (entries.isEmpty) return Padding(padding: const EdgeInsets.all(30), child: Center(child: Text(a ? 'لا توجد عناصر بعد. اضغط إضافة.' : 'No items yet. Tap Add item.')));
            return Column(children: entries.map((entry) => Card(child: ListTile(
              title: Text(entry.data()['title'] as String? ?? ''),
              subtitle: Text(entry.data()['details'] as String? ?? '', maxLines: 3),
              onTap: () => editItem(entry),
              trailing: IconButton(tooltip: a ? 'حذف' : 'Delete', icon: const Icon(Icons.delete_outline),
                onPressed: () async { try { await entry.reference.delete(); } catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(userFacingError(e)))); } }),
            ))).toList());
          }),
      ]),
    );
  }
}

class AccountPage extends StatefulWidget {
  const AccountPage({super.key});
  @override State<AccountPage> createState() => _AccountPageState();
}
class _AccountPageState extends State<AccountPage> {
  final user = FirebaseAuth.instance.currentUser!;
  final name = TextEditingController();
  bool busy = false;
  String language = 'en';
  @override void initState() { super.initState(); name.text = user.displayName ?? ''; load(); }
  Future<void> load() async {
    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      if (mounted && doc.exists) setState(() => language = (doc.data()?['language'] == 'ar') ? 'ar' : 'en');
    } catch (e) { if (mounted) message(userFacingError(e)); }
  }
  @override void dispose() { name.dispose(); super.dispose(); }
  Future<void> save() async {
    final displayName = name.text.trim();
    if (displayName.isEmpty || displayName.runes.length > 80) {
      message('Display name must be 1–80 characters / يجب أن يكون الاسم من ١ إلى ٨٠ حرفًا');
      return;
    }
    setState(() => busy = true);
    try {
      await user.updateDisplayName(displayName);
      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({'displayName': displayName, 'language': language, 'email': user.email, 'updatedAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile saved / تم حفظ الملف الشخصي')));
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(userFacingError(e)))); }
    finally { if (mounted) setState(() => busy = false); }
  }
  void message(String value) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value))); }
  Future<void> verifyEmail() async {
    try { await user.sendEmailVerification(); message('Verification email sent / تم إرسال رسالة التحقق'); }
    catch (e) { message(userFacingError(e)); }
  }
  Future<void> changePassword() async {
    final newPassword = TextEditingController();
    final value = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Change password / تغيير كلمة المرور'),
      content: TextField(controller: newPassword, obscureText: true, decoration: const InputDecoration(labelText: 'New password (6+ characters)')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, newPassword.text), child: const Text('Update'))]));
    newPassword.dispose();
    if (value == null) return;
    if (value.length < 6) { message('Password must have at least 6 characters'); return; }
    try { await user.updatePassword(value); message('Password updated'); }
    on FirebaseAuthException catch (e) { message(e.code == 'requires-recent-login' ? 'Please sign out and sign in again before changing password.' : e.message ?? e.code); }
    catch (e) { message(userFacingError(e)); }
  }
  // Server verifies ID token, deletes the entire Firestore subtree and finally Auth identity.
  // Never remove only the Firebase Auth account: it would orphan private data.
  static const backend = String.fromEnvironment('MINDHUB_API_BASE_URL');
  Future<void> exportData() async {
    if (backend.isEmpty) { message('Configure MINDHUB_API_BASE_URL to enable secure data export.'); return; }
    try {
      final token = await user.getIdToken();
      final r = await http.get(Uri.parse('$backend/v1/me/export'), headers: {'Authorization': 'Bearer $token'});
      if (r.statusCode != 200) throw Exception(apiError(r, 'Export'));
      if (!mounted) return;
      final payload = const JsonEncoder.withIndent('  ').convert(jsonDecode(r.body));
      await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('Your account data / بياناتك'),
        content: SizedBox(width: 560, height: 380, child: SingleChildScrollView(child: SelectableText(payload))),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))]));
    } catch (e) { message(userFacingError(e)); }
  }
  Future<void> deleteAccount() async {
    if (backend.isEmpty) { message('Configure MINDHUB_API_BASE_URL before account deletion.'); return; }
    final approved = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Permanently delete account? / حذف الحساب نهائياً؟'),
      content: const Text('This permanently deletes the account and its saved workspace items. This cannot be undone.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete permanently'))]));
    if (approved != true) return;
    final password = TextEditingController();
    final secret = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Confirm your password / أكد كلمة المرور'),
      content: TextField(controller: password, obscureText: true, autofocus: true,
        decoration: const InputDecoration(labelText: 'Current password / كلمة المرور الحالية')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, password.text), child: const Text('Confirm'))]));
    password.dispose();
    if (secret == null || secret.isEmpty) return;
    try {
      await user.reauthenticateWithCredential(EmailAuthProvider.credential(email: user.email!, password: secret));
      final token = await user.getIdToken(true);
      final r = await http.delete(Uri.parse('$backend/v1/me'), headers: {'Authorization': 'Bearer $token'});
      if (r.statusCode != 200) {
        throw Exception(apiError(r, 'Account deletion'));
      }
      await FirebaseAuth.instance.signOut();
      if (mounted) Navigator.pop(context);
    } on FirebaseAuthException catch (e) { message(e.code == 'wrong-password' || e.code == 'invalid-credential' ? 'Incorrect password / كلمة المرور غير صحيحة' : e.message ?? e.code); }
      catch (e) { message(userFacingError(e)); }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Account / الحساب')), body: ListView(padding: const EdgeInsets.all(24), children: [
    const CircleAvatar(radius: 32, child: Icon(Icons.person, size: 35)),
    const SizedBox(height: 14),
    Text(user.email ?? '', style: Theme.of(context).textTheme.titleMedium),
    Text(user.emailVerified ? 'Email verified ✓' : 'Email not verified', style: Theme.of(context).textTheme.bodySmall),
    const SizedBox(height: 16),
    TextField(controller: name, decoration: const InputDecoration(labelText: 'Display name / الاسم')),
    DropdownButtonFormField<String>(value: language, decoration: const InputDecoration(labelText: 'Preferred language / اللغة'), items: const [DropdownMenuItem(value: 'en', child: Text('English')), DropdownMenuItem(value: 'ar', child: Text('العربية'))], onChanged: (v) => setState(() => language = v ?? 'en')),
    const SizedBox(height: 20),
    FilledButton(onPressed: busy ? null : save, child: const Text('Save profile / حفظ الملف')),
    OutlinedButton(onPressed: () async { await FirebaseAuth.instance.sendPasswordResetEmail(email: user.email!); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Password reset email requested'))); }, child: const Text('Reset password / تغيير كلمة المرور')),
    OutlinedButton(onPressed: verifyEmail, child: const Text('Send verification email / تحقق من البريد')),
    OutlinedButton(onPressed: changePassword, child: const Text('Change password / تغيير كلمة المرور')),
    OutlinedButton(onPressed: exportData, child: const Text('View account data / عرض بياناتي')),
    OutlinedButton(onPressed: () async { Navigator.of(context).pop(); await FirebaseAuth.instance.signOut(); }, child: const Text('Sign out / تسجيل الخروج')),
    const Divider(height: 35),
    TextButton.icon(onPressed: deleteAccount, icon: const Icon(Icons.delete_forever), label: const Text('Delete my account / حذف الحساب'), style: TextButton.styleFrom(foregroundColor: Colors.redAccent)),
  ]));
}
