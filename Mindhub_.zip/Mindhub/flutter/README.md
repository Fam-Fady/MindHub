# MindHub Flutter + Firebase

The app packages all **23 original HTML mini-apps**, the bilingual launcher and the all-in-one HTML file as Flutter assets, shown in an embedded WebView (served from a local server on port 8087). Sign-in, profile, export and delete screens are native Flutter. The mini-apps were **not** rewritten as Flutter widgets.

## Build (recommended: GitHub Actions)
1. Create a Firebase project; enable **Authentication > Email/Password** and **Cloud Firestore**; register an Android app.
2. Deploy `firestore.rules` (`firebase deploy --only firestore:rules`).
3. Copy `firebase_build.example.json`, fill in your values (including `MINDHUB_API_BASE_URL` for the deployed API) and save the JSON as the repository secret `FIREBASE_DART_DEFINES_JSON`.
4. Run the **Android APK (Firebase connected)** workflow. It generates the Android project, adds the `INTERNET` permission and localhost cleartext setting, sets minSdk 23, runs analysis and builds the release APK.

## Build locally
1. `flutter create . --platforms=android --project-name=mindhub`
2. In `android/app/src/main/AndroidManifest.xml` add `<uses-permission android:name="android.permission.INTERNET"/>` above `<application` and `android:usesCleartextTraffic="true"` on `<application` (needed for the local `http://localhost:8087` asset server and for network access in release builds).
3. Set `minSdk = 23` in `android/app/build.gradle(.kts)`; delete `test/widget_test.dart`.
4. `flutter run --dart-define-from-file=firebase_build.json` (or `flutter build apk --release --dart-define-from-file=firebase_build.json`).

Firebase values come from `--dart-define` (see `firebase_build.example.json`); `flutterfire configure` is not used.

## Features
- Email/password sign-up (with email verification), login, logout, password reset, profile (name + language), cloud notes per app, data export and account deletion (through the API).
- Firestore rules (`firestore.rules`) cover the profile and the per-app notes; all other paths are denied.

## Limitations
- This repository contains source code; no APK or live backend is included, and the Flutter build and Firebase emulator tests have not been run.
- The mini-apps keep their own data in browser storage; it is not synced to the account.
- Features of the original HTML that need a separate Node.js or AI backend are not provided by this API.
