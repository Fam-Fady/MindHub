import {initializeApp} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import {getAuth,onAuthStateChanged,onIdTokenChanged,signInWithEmailAndPassword,createUserWithEmailAndPassword,sendPasswordResetEmail,sendEmailVerification,updateProfile,signOut,reauthenticateWithCredential,EmailAuthProvider} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {getFirestore,doc,getDoc,setDoc,serverTimestamp} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
const $=id=>document.getElementById(id), status=$('status');
const config=window.MINDHUB_FIREBASE_CONFIG;
const apiBase=(window.MINDHUB_API_BASE_URL||'').replace(/\/$/,'');
let current=null;
const notice=(en,ar)=>{status.textContent=document.documentElement.lang==='ar'?ar:en};
const showError=e=>notice(e.code==='permission-denied'?'Permission denied. Verify email and refresh.':(e.message||String(e)),e.code==='permission-denied'?'تم رفض الإذن. تحقق من البريد ثم حدّث الحالة.':(e.message||String(e)));
const act=async fn=>{status.textContent='';try{await fn()}catch(e){showError(e)}};
if(!config || Object.values(config).some(v=>!v || v==='REPLACE_ME')){
  notice('Configure firebase-config.js to enable accounts.','قم بإعداد Firebase لتفعيل الحسابات.');
  document.querySelectorAll('button:not(#lang)').forEach(b=>b.disabled=true);
}else{
  const app=initializeApp(config),auth=getAuth(app),db=getFirestore(app);
  async function renderUser(u){
    current=u;
    try { if (u) localStorage.setItem('mh_token', await u.getIdToken()); else localStorage.removeItem('mh_token'); } catch (_) {}
    const verified=!!u?.emailVerified;
    $('signedOut').hidden=!!u;
    $('needsVerification').hidden=!u||verified;
    $('signedIn').hidden=!u||!verified;
    if(!u)return;
    $('who').textContent=u.email||'';
    $('profileName').value=u.displayName||'';
    if(!verified){notice('Check your email, verify your address, then click refresh.','افتح بريدك وتحقق من العنوان ثم اضغط تحديث.');return;}
    try{const snap=await getDoc(doc(db,'users',u.uid));$('language').value=snap.data()?.language==='ar'?'ar':'en';}
    catch(e){showError(e)}
  }
  $('login').onclick=()=>act(()=>signInWithEmailAndPassword(auth,$('email').value.trim(),$('password').value));
  $('register').onclick=()=>act(async()=>{
    const displayName=$('name').value.trim();
    if(!displayName || Array.from(displayName).length>80)throw new Error('Enter a display name (1–80 characters). / أدخل اسمًا من ١ إلى ٨٠ حرفًا');
    const c=await createUserWithEmailAndPassword(auth,$('email').value.trim(),$('password').value);
    await updateProfile(c.user,{displayName});
    // Signup is allowed to write an initial profile, even for unverified addresses.
    await setDoc(doc(db,'users',c.user.uid),{displayName,email:c.user.email,language:'en',createdAt:serverTimestamp()});
    await sendEmailVerification(c.user);
    await renderUser(c.user);
  });
  $('reset').onclick=()=>act(async()=>{await sendPasswordResetEmail(auth,$('email').value.trim());notice('If the address is registered, check your email.','إذا كان البريد مسجلًا، فافحص رسائلك.')});
  $('resend').onclick=()=>act(async()=>{await sendEmailVerification(auth.currentUser);notice('Verification email sent.','تم إرسال رسالة التحقق.')});
  $('refresh').onclick=()=>act(async()=>{
    await auth.currentUser.reload();await auth.currentUser.getIdToken(true);
    await renderUser(auth.currentUser);
    if(auth.currentUser.emailVerified)notice('Email verified. You can now save your profile.','تم التحقق من البريد، يمكنك الآن حفظ ملفك.');
  });
  $('save').onclick=()=>act(async()=>{
    if(!current?.emailVerified)throw new Error('Verify your email first.');
    const displayName=$('profileName').value.trim();
    if(!displayName || Array.from(displayName).length>80)throw new Error('Display name must contain 1–80 characters.');
    await updateProfile(current,{displayName});
    await setDoc(doc(db,'users',current.uid),{displayName,language:$('language').value,email:current.email,updatedAt:serverTimestamp()},{merge:true});
    notice('Saved.','تم الحفظ.');
  });
  const authApi=async(method,path)=>{
    if(!apiBase || apiBase==='REPLACE_ME')throw new Error('Configure MINDHUB_API_BASE_URL in firebase-config.js first.');
    const token=await auth.currentUser.getIdToken(true);
    const response=await fetch(apiBase+path,{method,headers:{Authorization:`Bearer ${token}`}});
    const result=await response.json().catch(()=>({}));
    if(!response.ok)throw new Error(result.error||`Request failed (${response.status})`);
    return result;
  };
  const exportData=()=>act(async()=>{
    const data=await authApi('GET','/v1/me/export');
    const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json;charset=utf-8'});
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='mindhub-account-export.json';
    document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
    notice('Export downloaded.','تم تنزيل نسخة البيانات.');
  });
  // Never show Firebase's untranslated SDK messages inside the delete dialog.
  // Match stable error codes rather than their English descriptions.
  const deletionErrorMessage = (error) => {
    const ar = document.documentElement.lang === 'ar';
    const code = String(error?.code || '').replace(/^auth\//, '');
    const messages = {
      'wrong-password': ['Incorrect password.', 'كلمة المرور غير صحيحة.'],
      'invalid-credential': ['Incorrect email or password.', 'البريد الإلكتروني أو كلمة المرور غير صحيحة.'],
      'too-many-requests': ['Too many attempts. Please try again later.', 'محاولات كثيرة جدًا. حاول مرة أخرى لاحقًا.'],
      'network-request-failed': ['Network error. Check your connection and retry.', 'حدث خطأ في الشبكة. تحقق من اتصالك وحاول مجددًا.'],
      'user-disabled': ['This account is disabled.', 'هذا الحساب معطّل.'],
      'requires-recent-login': ['Please sign in again before deleting.', 'يرجى تسجيل الدخول مجددًا قبل الحذف.'],
      'permission-denied': ['Permission denied. Please sign in again.', 'تم رفض الإذن. يرجى تسجيل الدخول مجددًا.']
    };
    if (messages[code]) return messages[code][ar ? 1 : 0];
    // API responses are intentionally mapped to localized, safe user messages.
    const apiCode = String(error?.message || '').toLowerCase();
    if (apiCode.includes('recent_login_required') || apiCode.includes('recent login'))
      return ar ? 'يرجى تسجيل الدخول مجددًا قبل الحذف.' : 'Please sign in again before deleting.';
    if (apiCode.includes('429') || apiCode.includes('rate limit'))
      return ar ? 'طلبات كثيرة جدًا. حاول لاحقًا.' : 'Too many requests. Please try later.';
    if (apiCode.includes('failed to fetch') || apiCode.includes('network'))
      return ar ? 'تعذّر الاتصال بالخادم. تحقق من الشبكة.' : 'Cannot reach the server. Check your connection.';
    return ar ? 'تعذّر حذف الحساب. حاول مرة أخرى لاحقًا.' : 'Could not delete the account. Please try again.';
  };
  const deleteDialog=$('deleteDialog'), deletePassword=$('deletePassword'), deleteError=$('deleteError');
  const dialogError=(message)=>{deleteError.textContent=message;deleteError.hidden=!message;};
  const deleteAccount=()=>{
    status.textContent='';
    deletePassword.value='';
    dialogError('');
    deleteDialog.showModal();
    deletePassword.focus();
  };
  $('cancelDelete').onclick=()=>deleteDialog.close();
  $('deleteForm').addEventListener('submit',async event=>{
    event.preventDefault();
    if ($('confirmDelete').disabled) return;
    dialogError('');
    const password=deletePassword.value;
    if(!password){dialogError(document.documentElement.lang==='ar'?'أدخل كلمة المرور الحالية.':'Enter your current password.');return;}
    $('confirmDelete').disabled=true;
    try{
      const user=auth.currentUser;
      await reauthenticateWithCredential(user,EmailAuthProvider.credential(user.email,password));
      await authApi('DELETE','/v1/me');
      deleteDialog.close();
      deletePassword.value='';
      await signOut(auth);
      notice('Account deleted.','تم حذف الحساب.');
    }catch(e){
      dialogError(deletionErrorMessage(e));
    }finally{$('confirmDelete').disabled=false;}
  });
  $('export').onclick=exportData;$('pendingExport').onclick=exportData;
  $('deleteAccount').onclick=deleteAccount;$('pendingDelete').onclick=deleteAccount;
  $('logout').onclick=$('pendingLogout').onclick=()=>act(()=>signOut(auth));
  onAuthStateChanged(auth,u=>{renderUser(u).catch(showError)});
  onIdTokenChanged(auth,async u=>{try{if(u)localStorage.setItem('mh_token',await u.getIdToken());else localStorage.removeItem('mh_token')}catch(_){}});
}
$('lang').onclick=()=>{const ar=document.documentElement.lang!=='ar';document.documentElement.lang=ar?'ar':'en';document.documentElement.dir=ar?'rtl':'ltr';$('lang').textContent=ar?'English':'العربية';for(const e of document.querySelectorAll('[data-en]'))e.textContent=e.dataset[ar?'ar':'en']};
