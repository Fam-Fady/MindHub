// Copy your Firebase Web App configuration here from Firebase Console.
// Firebase Console > Project settings > Your apps > Web app.
window.MINDHUB_FIREBASE_CONFIG = {
  apiKey: "REPLACE_ME", authDomain: "REPLACE_ME", projectId: "REPLACE_ME",
  appId: "REPLACE_ME"
};

// HTTPS address of your deployed MindHub backend (no trailing slash).
window.MINDHUB_API_BASE_URL = 'REPLACE_ME';
