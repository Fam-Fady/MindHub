# MindHub deployment and APK instructions

## 1. Create your real Firebase project (account owner required)
Open https://console.firebase.google.com/ ; create a Firebase project; enable **Authentication → Sign-in method → Email/Password**, and create **Firestore**. Register an Android app (example ID `com.example.mindhub`) and a Web app under the SAME project. The Firebase configuration values are public client identifiers, but **never include a Firebase Admin service-account private key in client builds**.

## 2. Android / Flutter configuration
Create `flutter/firebase_build.json` by copying `flutter/firebase_build.example.json`, replacing all placeholder values with values from **Project Settings → Your apps** and the deployed API URL. Do NOT commit firebase_build.json. From the `flutter` folder on a computer with Flutter SDK and Android toolchain:

```bash
flutter create . --platforms=android --project-name=mindhub
flutter pub get
flutter analyze
flutter build apk --release --dart-define-from-file=firebase_build.json
```

The resulting installable file is `flutter/build/app/outputs/flutter-apk/app-release.apk`. Android release build defaults to the Flutter template debug signing if no proper upload key is configured; before Play Store distribution, configure a real release/upload signing key per Flutter Android deployment documentation. **This archive does NOT contain a compiled APK.**

## 3. Build remotely if Flutter SDK isn't installed locally
Upload this folder to a *private* GitHub repository. In **Settings → Secrets and variables → Actions**, create repository secret **FIREBASE_DART_DEFINES_JSON** containing the exact JSON object (not path) from your populated firebase_build.json. In **Actions**, run **Android APK (Firebase connected)**. Download the resulting `MindHub-release-APK` artifact. GitHub-hosted runners install Flutter and Android toolchains automatically. Builds require network and correct project identifiers.

## 4. Deploy API (actual server)
The `backend/` Node.js server uses Firebase Admin via Google Application Default Credentials, verifies every Firebase ID token for private routes, and reads/writes Firestore. It exposes `GET /health` publicly; `GET /v1/me`, `PATCH /v1/me`, `GET /v1/me/export`, and `DELETE /v1/me` require a bearer ID token. Use Cloud Run or another Node 20+ host. One deployment option is:

```bash
gcloud auth login
gcloud config set project YOUR_PROJECT_ID
gcloud run deploy mindhub-api --source backend --region us-central1 --allow-unauthenticated
```

Enable required Google Cloud APIs (Cloud Run, Cloud Build and Artifact Registry), configure billing as required, and attach a runtime service account with the minimum Firestore/Firebase Auth permissions. `--allow-unauthenticated` only permits reaching the public HTTP service: the API itself still verifies bearer tokens before private operations. Restrict ALLOWED_ORIGIN to the website origin for browser clients and add production monitoring and request limits. Alternatively run the included GitHub `Deploy MindHub API to Cloud Run` action after setting `GCP_WORKLOAD_IDENTITY_PROVIDER`, `GCP_DEPLOY_SERVICE_ACCOUNT`, `GCP_PROJECT_ID` secrets and optional `GCP_REGION`, `MINDHUB_HTML_ORIGIN` variables.

## 5. HTML website — HTTPS is required for accounts

**Do not double-click `account.html` to sign in.** A `file://` page does not provide a supported Firebase Auth/module hosting origin. Double-clicking `index.html` can still show the static launcher, but accounts must use HTTPS hosting.

1. Host the **entire** `html/` directory with Firebase Hosting or another HTTPS service (retain `account.js`, `firebase-config.js`, and `apps/`).
2. In Firebase Console → Authentication → Settings → Authorized domains, add the exact website **hostname** (without `https://`).
3. Fill out `html/firebase-config.js`, including the HTTPS `MINDHUB_API_BASE_URL`.
4. Deploy the backend with `ALLOWED_ORIGIN` matching the **website origin**, for example `https://mindhub.example.com` (no path/trailing slash). Do not use `*`.
5. Confirm login, verification, export, deletion, and browser preflight `OPTIONS` using the hosted site.
6. For development use an HTTP localhost dev server and authorize `localhost` in Firebase; production must use HTTPS.

### Anonymous traffic protection on Cloud Run

The Node API's per-user rate limit runs **after** Firebase token verification; it is not an anonymous DDoS defense. Before making the service public, front Cloud Run with an external Application Load Balancer + Cloud Armor (or a suitable authenticated gateway/WAF). Attach a rate-limiting policy based on trusted client identity/IP at the edge, set reasonable request caps, and protect unauthenticated routes; only trust forwarded IP headers from your configured proxy. Restrict direct Cloud Run ingress to `internal-and-cloud-load-balancing` so requests cannot bypass the edge policy. Review billing impact, monitor blocked traffic, and validate legitimate traffic. No Cloud Armor policy is installed by this ZIP.

## 5A. Original HTML website notes
Keep `html/` as a separate website. Set its Firebase Web config in `html/firebase-config.js` using the same Firebase project, and publish it through HTTPS. Deploy the included `flutter/firestore.rules` rules using Firebase CLI with the project owner credentials; review and test them first.

## 6. Current limitations
- A live Firebase project cannot be created without YOUR account permission and project-specific identifiers.
- Flutter/Android SDKs are **not installed inside this chat environment**; the build is automated on GitHub Actions instead. No APK has been compiled or device-tested here.
- All 23 original HTML mini-apps are preserved. Flutter has a native dashboard and native Firestore-backed notes/workspace per mini-app, with original tools through WebView. It is not a full native rewrite of all specialized features.
- The app needs integration testing (especially WebView localhost behavior, Firebase Auth, and export/delete API calls) once Firebase and an emulator/device are available.

## Security and feature status (October 2026 patch)

- The Flutter deletion screen asks for the current password and reauthenticates before the API call. The API still checks a recent login.
- The API uses UTF-8 request decoding, requires verified email, and has single-instance in-memory rate limiting. Put a distributed rate limiter or API gateway in front of a scaled deployment.
- Flutter signup sends verification email and blocks the dashboard until verification. Existing signed-in users may need to verify their email.
- Firestore rules check timestamp types and ensure provided timestamps match server request time. Deploy updated rules before deploying the revised app.
- `package-lock.json` could not be produced in this offline environment because the npm registry is inaccessible. On a connected machine run `cd backend && npm install --package-lock-only`, commit the generated lockfile, and replace Docker's `npm install` with `npm ci --omit=dev`.
- The 23 original HTML mini-apps are NOT cloud-synchronized. See SYNC_STATUS.md.
- No Firebase project credentials, deployed server, Flutter build, or APK are included.
