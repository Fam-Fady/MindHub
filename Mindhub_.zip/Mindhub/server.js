#!/usr/bin/env node
/*
 * MindHub local server — no npm install needed (Node 16+ only).
 *
 *   node server.js            -> http://localhost:3000
 *   PORT=8080 node server.js  -> http://localhost:8080
 *
 * Serves the ./html folder AND the /api/* endpoints the app expects
 * (accounts, sessions, prefs, progress, notifications, health).
 * Data is stored in ./data/db.json. Passwords are hashed with scrypt.
 *
 * Email is not sent from a local machine, so accounts are auto-verified and
 * password-reset tokens are returned directly to the page.
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const ROOT = path.join(__dirname, 'html');
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

/* ---------------- storage ---------------- */
let db = { users: {}, sessions: {}, resets: {} };
try {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (fs.existsSync(DB_FILE)) db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8')));
} catch (e) {
  console.error('Could not read data/db.json, starting fresh:', e.message);
}
let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      const tmp = DB_FILE + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(db));
      fs.renameSync(tmp, DB_FILE);
    } catch (e) { console.error('Save failed:', e.message); }
  }, 100);
}
process.on('SIGINT', () => { try { fs.writeFileSync(DB_FILE, JSON.stringify(db)); } catch (_) {} process.exit(0); });

/* ---------------- helpers ---------------- */
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const rid = (n = 24) => crypto.randomBytes(n).toString('hex');

function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(pw, salt, 64);
  return salt.toString('hex') + ':' + h.toString('hex');
}
function checkPassword(pw, stored) {
  try {
    const [saltHex, hashHex] = stored.split(':');
    const h = crypto.scryptSync(pw, Buffer.from(saltHex, 'hex'), 64);
    return crypto.timingSafeEqual(h, Buffer.from(hashHex, 'hex'));
  } catch (_) { return false; }
}
const publicUser = (u) => ({
  id: u.id, email: u.email, displayName: u.displayName || null,
  emailVerified: true, createdAt: u.createdAt
});

const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  const p = hits.get(key);
  if (!p || p.reset <= now) { hits.set(key, { n: 1, reset: now + windowMs }); return false; }
  return ++p.n > max;
}

function send(res, status, body, extra) {
  const headers = Object.assign({
    'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store'
  }, extra || {});
  res.writeHead(status, headers);
  res.end(JSON.stringify(body));
}
const fail = (res, status, code, error) => send(res, status, { error: error || code, code });

async function readJson(req, limit = 5 * 1024 * 1024) {
  let size = 0; const chunks = [];
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw Object.assign(new Error('too large'), { status: 413 });
    chunks.push(c);
  }
  const text = Buffer.concat(chunks).toString('utf8');
  if (!text) return {};
  try { return JSON.parse(text); } catch (_) { throw Object.assign(new Error('bad json'), { status: 400 }); }
}

function parseCookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach((p) => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
function tokenFrom(req) {
  const m = /^Bearer (.+)$/i.exec(req.headers.authorization || '');
  return (m && m[1]) || parseCookies(req).mh_session || '';
}
function sessionFor(req) {
  const t = tokenFrom(req);
  if (!t) return null;
  const s = db.sessions[sha(t)];
  if (!s) return null;
  const user = db.users[s.userId];
  if (!user) return null;
  return { session: s, user, hash: sha(t) };
}
function newSession(req, user) {
  const token = rid(32);
  db.sessions[sha(token)] = {
    id: rid(6), userId: user.id, createdAt: Date.now(),
    ua: String(req.headers['user-agent'] || '').slice(0, 120),
    ip: req.socket.remoteAddress || ''
  };
  save();
  return token;
}
const cookieFor = (token, maxAge) =>
  `mh_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge == null ? 60 * 60 * 24 * 30 : maxAge}`;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
function validCreds(res, email, password, checkLen) {
  if (!email) { fail(res, 400, 'email_required'); return false; }
  if (!EMAIL_RE.test(email)) { fail(res, 400, 'email_invalid'); return false; }
  if (!password) { fail(res, 400, 'password_required'); return false; }
  if (checkLen && password.length < 8) { fail(res, 400, 'password_short'); return false; }
  if (password.length > 200) { fail(res, 400, 'password_long'); return false; }
  return true;
}

/* ---------------- API ---------------- */
async function handleApi(req, res, pathname) {
  const m = req.method;
  const ip = req.socket.remoteAddress || 'x';

  if (pathname === '/api/health') {
    return send(res, 200, { ok: true, service: 'mindhub-local', configured: false });
  }

  /* ----- auth: public ----- */
  if (pathname === '/api/auth/signup' && m === 'POST') {
    if (limited('auth:' + ip, 30, 60000)) return fail(res, 429, 'rate_limited');
    const body = await readJson(req);
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (!validCreds(res, email, password, true)) return;
    if (Object.values(db.users).some((u) => u.email === email)) return fail(res, 409, 'email_taken');
    const user = { id: rid(8), email, pass: hashPassword(password), displayName: null,
      createdAt: Date.now(), data: { prefs: null, progress: {}, notifications: [] } };
    db.users[user.id] = user;
    const token = newSession(req, user);
    return send(res, 200, { token, user: publicUser(user) }, { 'Set-Cookie': cookieFor(token) });
  }

  if (pathname === '/api/auth/login' && m === 'POST') {
    if (limited('auth:' + ip, 30, 60000)) return fail(res, 429, 'rate_limited');
    const body = await readJson(req);
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (!validCreds(res, email, password, false)) return;
    const user = Object.values(db.users).find((u) => u.email === email);
    if (!user || !checkPassword(password, user.pass)) return fail(res, 401, 'bad_credentials');
    const token = newSession(req, user);
    return send(res, 200, { token, user: publicUser(user) }, { 'Set-Cookie': cookieFor(token) });
  }

  if (pathname === '/api/auth/forgot-password' && m === 'POST') {
    if (limited('auth:' + ip, 30, 60000)) return fail(res, 429, 'rate_limited');
    const body = await readJson(req);
    const email = String(body.email || '').trim().toLowerCase();
    if (!EMAIL_RE.test(email)) return fail(res, 400, 'email_invalid');
    const user = Object.values(db.users).find((u) => u.email === email);
    const out = { ok: true };
    if (user) {
      const token = rid(16);
      db.resets[sha(token)] = { userId: user.id, exp: Date.now() + 30 * 60000 };
      save();
      out.resetToken = token; // no mail server locally, so hand it to the page
    }
    return send(res, 200, out);
  }

  if (pathname === '/api/auth/reset-password' && m === 'POST') {
    if (limited('auth:' + ip, 30, 60000)) return fail(res, 429, 'rate_limited');
    const body = await readJson(req);
    const password = String(body.password || '');
    if (password.length < 8) return fail(res, 400, 'password_short');
    const r = db.resets[sha(String(body.token || ''))];
    if (!r || r.exp < Date.now() || !db.users[r.userId]) return fail(res, 400, 'token_invalid');
    db.users[r.userId].pass = hashPassword(password);
    delete db.resets[sha(String(body.token))];
    for (const k of Object.keys(db.sessions)) if (db.sessions[k].userId === r.userId) delete db.sessions[k];
    save();
    return send(res, 200, { ok: true });
  }

  if (pathname === '/api/auth/verify-email' && m === 'POST') {
    const s = sessionFor(req);
    return send(res, 200, { ok: true, user: s ? publicUser(s.user) : undefined });
  }

  /* ----- /me: tolerate signed-out ----- */
  const auth = sessionFor(req);
  if (pathname === '/api/auth/me' && m === 'GET') {
    return send(res, 200, { user: auth ? publicUser(auth.user) : null });
  }
  if (pathname === '/api/auth/logout' && m === 'POST') {
    if (auth) { delete db.sessions[auth.hash]; save(); }
    return send(res, 200, { ok: true }, { 'Set-Cookie': cookieFor('', 0) });
  }

  /* ----- everything below needs a session ----- */
  if (!auth) return fail(res, 401, 'auth_required', 'Sign in to use MindHub.');
  const { user } = auth;
  if (limited('u:' + user.id, 600, 60000)) return fail(res, 429, 'rate_limited');
  user.data = user.data || { prefs: null, progress: {}, notifications: [] };

  switch (pathname + ' ' + m) {
    case '/api/auth/resend-verification POST':
      return send(res, 200, { ok: true });

    case '/api/auth/profile PATCH': {
      const body = await readJson(req);
      const dn = body.displayName == null ? null : String(body.displayName).trim().slice(0, 60);
      user.displayName = dn || null; save();
      return send(res, 200, { user: publicUser(user) });
    }

    case '/api/auth/change-password POST': {
      const body = await readJson(req);
      const cur = String(body.currentPassword || ''), neu = String(body.newPassword || '');
      if (!checkPassword(cur, user.pass)) return fail(res, 400, 'current_password_wrong');
      if (neu.length < 8) return fail(res, 400, 'password_short');
      if (neu === cur) return fail(res, 400, 'password_same');
      user.pass = hashPassword(neu);
      for (const k of Object.keys(db.sessions))
        if (db.sessions[k].userId === user.id && k !== auth.hash) delete db.sessions[k];
      save();
      return send(res, 200, { ok: true });
    }

    case '/api/auth/delete-account POST': {
      const body = await readJson(req);
      if (!checkPassword(String(body.password || ''), user.pass)) return fail(res, 400, 'current_password_wrong');
      for (const k of Object.keys(db.sessions)) if (db.sessions[k].userId === user.id) delete db.sessions[k];
      delete db.users[user.id]; save();
      return send(res, 200, { ok: true }, { 'Set-Cookie': cookieFor('', 0) });
    }

    case '/api/auth/sessions GET': {
      const list = Object.entries(db.sessions).filter(([, s]) => s.userId === user.id)
        .map(([k, s]) => ({ id: s.id, createdAt: s.createdAt, ua: s.ua, ip: s.ip, current: k === auth.hash }));
      return send(res, 200, { sessions: list });
    }

    case '/api/auth/sessions/revoke POST': {
      const body = await readJson(req);
      let n = 0;
      for (const k of Object.keys(db.sessions)) {
        if (db.sessions[k].userId !== user.id) continue;
        if (body.all || (body.others && k !== auth.hash)) { delete db.sessions[k]; n++; }
      }
      save();
      return send(res, 200, { ok: true, revoked: n });
    }

    case '/api/auth/export GET':
      return send(res, 200, { app: 'mindhub', exportedAt: new Date().toISOString(),
        user: publicUser(user), data: user.data },
        { 'Content-Disposition': 'attachment; filename="mindhub-export.json"' });

    case '/api/auth/import POST': {
      const body = await readJson(req);
      const d = body && body.data;
      if (!d || typeof d !== 'object') return fail(res, 400, 'invalid_import');
      user.data = {
        prefs: d.prefs && typeof d.prefs === 'object' ? d.prefs : user.data.prefs,
        progress: d.progress && typeof d.progress === 'object' ? d.progress : user.data.progress,
        notifications: Array.isArray(d.notifications) ? d.notifications.slice(-500) : user.data.notifications
      };
      save();
      return send(res, 200, { ok: true, user: publicUser(user) });
    }

    /* ----- synced app data ----- */
    case '/api/prefs GET':
      return send(res, 200, { prefs: user.data.prefs });
    case '/api/prefs POST': {
      const body = await readJson(req);
      if (body.prefs && typeof body.prefs === 'object') { user.data.prefs = body.prefs; save(); }
      return send(res, 200, { ok: true, prefs: user.data.prefs });
    }

    case '/api/progress GET':
      return send(res, 200, { progress: user.data.progress || {} });
    case '/api/progress POST': {
      const b = await readJson(req);
      const app = String(b.app || '').slice(0, 40), metric = String(b.metric || '').slice(0, 60);
      if (!app || !metric) return fail(res, 400, 'invalid_field');
      const p = (user.data.progress[app] = user.data.progress[app] || { metrics: {}, days: {} });
      p.metrics[metric] = b.value;
      if (b.date) {
        const day = String(b.date).slice(0, 10);
        p.days[day] = Object.assign(p.days[day] || {}, { [metric]: b.value });
      }
      p.updatedAt = Date.now(); save();
      return send(res, 200, { ok: true });
    }

    case '/api/notifications GET':
      return send(res, 200, { notifications: user.data.notifications || [] });
    case '/api/notifications POST': {
      const b = await readJson(req);
      const n = b.notification;
      if (n && typeof n === 'object' && n.id) {
        const list = user.data.notifications = user.data.notifications || [];
        const i = list.findIndex((x) => x && x.id === n.id);
        if (i >= 0) list[i] = n; else list.push(n);
        if (list.length > 500) list.splice(0, list.length - 500);
        save();
      }
      return send(res, 200, { ok: true });
    }

    case '/api/chat POST':
      // No AI provider is wired into the local server; the page falls back to its built-in tips.
      return fail(res, 503, 'ai_not_configured', 'AI is not configured on this local server.');
  }

  return fail(res, 404, 'not_found', 'Not found');
}

/* ---------------- static files ---------------- */
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.webp': 'image/webp', '.txt': 'text/plain; charset=utf-8',
  '.woff2': 'font/woff2', '.woff': 'font/woff', '.webmanifest': 'application/manifest+json'
};
function serveStatic(req, res, pathname) {
  let rel;
  try { rel = decodeURIComponent(pathname); } catch (_) { res.writeHead(400); return res.end(); }
  if (rel === '/' || rel === '') rel = '/MindHub-All-in-One.html';
  const file = path.normalize(path.join(ROOT, rel));
  if (file !== ROOT && !file.startsWith(ROOT + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, {
      'Content-Type': TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-cache'
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

/* ---------------- server ---------------- */
const server = http.createServer(async (req, res) => {
  let pathname = '/';
  try { pathname = new URL(req.url, 'http://x').pathname; } catch (_) {}
  try {
    if (pathname.startsWith('/api/')) return await handleApi(req, res, pathname);
    return serveStatic(req, res, pathname);
  } catch (e) {
    if (e && e.status) return fail(res, e.status, 'bad_request', e.message);
    console.error(e);
    if (!res.headersSent) return fail(res, 500, 'server_error');
    res.end();
  }
});

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error(`\nPort ${PORT} is already in use. Try:  PORT=3001 node server.js\n`);
  } else console.error(e);
  process.exit(1);
});

server.listen(PORT, HOST, () => {
  console.log('\n  MindHub is running.\n');
  console.log(`  Open:  http://localhost:${PORT}\n`);
  console.log('  Press Ctrl+C to stop.\n');
});
