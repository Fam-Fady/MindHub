# MindHub

MindHub is an all-in-one digital platform that brings productivity tools, learning resources, personal projects, and AI assistance together in one place.

Its main languages are **Arabic and English**, with support for right-to-left (RTL) Arabic and left-to-right (LTR) English layouts. MindHub is designed to be welcoming and accessible to people with different abilities and levels of technical experience.

## Features

- **Productivity and learning tools:** A collection of tools to help users study, work, organize, and create.
- **AI chatbot:** An assistant for asking questions, exploring ideas, and getting guidance.
- **Arabic and English:** Bilingual interface with language-appropriate text direction.
- **Accessibility options:** Features such as keyboard navigation, screen-reader-friendly labels, adjustable text sizes, high contrast, and reduced motion.
- **Multi-device experience:** Designed for computers, tablets, and smartphones.
- **Cloud synchronization:** Aims to keep user information available across devices through one account.
- **Offline support:** Selected app resources can remain available when an internet connection is unavailable.
- **Installable experience:** Supports a Progressive Web App (PWA) experience in compatible browsers.

## Platforms

MindHub is designed around a responsive web experience and includes a Flutter project for mobile app development. The web app can also be installed as a PWA in supported browsers.

## Languages

MindHub's primary languages are:

- English (left-to-right)
- العربية (من اليمين إلى اليسار)

## Accessibility

MindHub aims to make its tools easier to use through keyboard access, clear focus indicators, screen-reader support, adjustable text presentation, high-contrast options, and reduced-motion preferences.

## Project Structure

- `html/` — Web application and its mini-apps.
- `backend/` — Server-side API.
- `flutter/` — Flutter mobile application and bundled web assets.

## Getting Started

1. Open the project in your code editor.
2. Review the application configuration files and set the values required for your environment.
3. Start the backend using the instructions and scripts provided in the `backend/` directory.
4. Serve the contents of the `html/` directory through a local web server.
5. Open the local web address in a modern browser.

For mobile development, open the `flutter/` directory with Flutter-compatible development tools and use the Flutter project's run commands.

## Project Goal

MindHub aims to bring useful digital tools into one connected, inclusive platform—helping people learn, work, organize, and create in Arabic or English, across their devices.
