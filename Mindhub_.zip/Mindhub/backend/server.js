import http from 'node:http';
import { initializeApp, applicationDefault } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';

// Application Default Credentials on Cloud Run. NEVER commit service account secrets.
initializeApp({ credential: applicationDefault() });
const db = getFirestore();
const port = Number(process.env.PORT || 8080);
const origin = process.env.ALLOWED_ORIGIN || '';
const json = (res, status, body) => {
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store',
    ...(origin ? {'Access-Control-Allow-Origin': origin, 'Vary':'Origin'} : {})});
  res.end(JSON.stringify(body));
};
const limitedBody = async (req, maxBytes = 8192) => {
  req.setEncoding('utf8');
  let body = '';
  for await (const chunk of req) { body += chunk; if (body.length > maxBytes) throw Object.assign(new Error('Request too large'), {status:413}); }
  try { return JSON.parse(body || '{}'); } catch { throw Object.assign(new Error('Invalid JSON'), {status:400}); }
};
// Account-level limiter after token verification. Do not key by req.socket.remoteAddress:
// on Cloud Run it may identify the reverse proxy, not the individual visitor.
// This limiter is only a per-instance safety net. Configure a trusted gateway/WAF
// with distributed anonymous-abuse controls in production.
const requests = new Map();
const rateLimit = (key, max, windowMs) => {
  const now = Date.now();
  if (requests.size > 10000) for (const [k, v] of requests) if (v.reset <= now) requests.delete(k);
  const prior = requests.get(key);
  if (!prior || prior.reset <= now) { requests.set(key, {count:1, reset:now+windowMs}); return false; }
  return ++prior.count > max;
};
const server = http.createServer(async (req, res) => {
  try {
    const path = new URL(req.url || '/', 'http://localhost').pathname;
    if (req.method === 'GET' && path === '/health') return json(res, 200, {ok:true, service:'mindhub-api'});
    if (req.method === 'OPTIONS' && origin && req.headers.origin === origin) {
      res.writeHead(204, {'Access-Control-Allow-Origin': origin, 'Access-Control-Allow-Methods': 'GET, PATCH, DELETE, PUT, POST, OPTIONS', 'Access-Control-Allow-Headers':'Authorization, Content-Type', 'Vary':'Origin'});
      return res.end();
    }
    const workspaceMatch = /^\/v1\/workspaces\/([a-z0-9-]+)$/.exec(path);
    const isChat = path === '/v1/chat' && req.method === 'POST';
    const isWorkspace = !!workspaceMatch && ['GET','PUT'].includes(req.method);
    if (!isChat && !isWorkspace && (!['GET','PATCH','DELETE'].includes(req.method) || !['/v1/me','/v1/me/export'].includes(path)))
      return json(res,404,{error:'Not found'});
    const match = /^Bearer (.+)$/i.exec(req.headers.authorization || '');
    if (!match) return json(res,401,{error:'Authentication required'});
    let decoded;
    try { decoded = await getAuth().verifyIdToken(match[1], true); }
    catch { return json(res,401,{error:'Invalid or revoked session'}); }
    const uid = decoded.uid;
    // Users must be able to export and delete even when their email cannot be verified.
    const selfService = (req.method === 'GET' && path === '/v1/me/export') || (req.method === 'DELETE' && path === '/v1/me');
    if (!decoded.email_verified && !selfService) return json(res,403,{error:'Verify your email to use this API',code:'email_not_verified'});
    if (rateLimit(`user:${uid}`, 60, 60000)) return json(res,429,{error:'Too many requests; try again later',code:'rate_limited'});
    if (isWorkspace) {
      const appId = workspaceMatch[1];
      const allowedApps = new Set(['codroutine','floweasy','forma3d','labyrinth','lingua','mindecho','mindmoney','mindvault','mindwell','minihub','offline-toolkit','pathora','pixelforge','plant_doctor','playlab','playworld','quillix','roamly','synaptix','terranest','vendora','veyra','voxora']);
      if (!allowedApps.has(appId)) return json(res,404,{error:'Unknown MindHub app'});
      const workspace = db.collection('users').doc(uid).collection('workspaces').doc(appId).collection('items').doc('state');
      if (req.method === 'GET') {
        const snap = await workspace.get();
        return json(res,200,{state:snap.exists ? (snap.data().state || {}) : {}, updatedAt:snap.exists ? snap.data().updatedAt || null : null});
      }
      const body = await limitedBody(req, 750000);
      if (!body.state || typeof body.state !== 'object' || Array.isArray(body.state) || JSON.stringify(body.state).length > 700000)
        return json(res,400,{error:'Invalid workspace state (maximum 700 KB)'});
      await workspace.set({state:body.state, updatedAt:FieldValue.serverTimestamp()});
      return json(res,200,{ok:true});
    }
    if (isChat) {
      if (!process.env.AI_API_KEY) return json(res,503,{error:'AI assistant is not configured yet',code:'ai_not_configured'});
      if (rateLimit(`chat:${uid}`, 20, 60000)) return json(res,429,{error:'AI message limit reached; try again shortly',code:'ai_rate_limited'});
      const body = await limitedBody(req, 60000);
      const messages = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
      if (!messages.length || messages.some(m => !m || !['user','assistant'].includes(m.role) || typeof m.content !== 'string' || m.content.length > 4000))
        return json(res,400,{error:'Provide up to 12 valid chat messages'});
      const endpoint = process.env.AI_API_URL || 'https://api.openai.com/v1/chat/completions';
      const model = process.env.AI_MODEL || 'gpt-4o-mini';
      const aiResponse = await fetch(endpoint, {
        method:'POST',
        headers:{'Authorization':`Bearer ${process.env.AI_API_KEY}`,'Content-Type':'application/json'},
        body:JSON.stringify({model, messages:[{role:'system',content:'You are MindHub Assistant. Be helpful, clear, safe, and concise. Support English and Arabic; reply in the language the user uses.'},...messages],temperature:0.5})
      });
      const aiData = await aiResponse.json().catch(()=>({}));
      if (!aiResponse.ok) {
        console.error('AI provider error:', aiResponse.status);
        return json(res,502,{error:'AI service is temporarily unavailable',code:'ai_provider_error'});
      }
      const answer = aiData.choices?.[0]?.message?.content;
      if (typeof answer !== 'string' || !answer.trim()) return json(res,502,{error:'AI returned an empty response'});
      return json(res,200,{answer:answer.trim(),model});
    }
    const ref = db.collection('users').doc(uid);
    if (req.method === 'GET' && path === '/v1/me') {
      const doc = await ref.get();
      return json(res,200,{uid, email:decoded.email || '', profile:doc.data() || {}});
    }
    if (req.method === 'PATCH' && path === '/v1/me') {
      const body = await limitedBody(req);
      if (typeof body.displayName !== 'string' || [...body.displayName.trim()].length === 0 || [...body.displayName.trim()].length > 80 ||
          !['ar','en'].includes(body.language)) return json(res,400,{error:'Invalid profile fields'});
      const displayName = body.displayName.trim();
      await getAuth().updateUser(uid,{displayName});
      await ref.set({displayName, language:body.language, email:decoded.email || '', updatedAt:FieldValue.serverTimestamp()},{merge:true});
      return json(res,200,{ok:true});
    }
    if (req.method === 'GET' && path === '/v1/me/export') {
      const profile = await ref.get();
      const workspaces = {};
      for (const appId of ['codroutine','floweasy','forma3d','labyrinth','lingua','mindecho','mindmoney','mindvault','mindwell','minihub','offline-toolkit','pathora','pixelforge','plant_doctor','playlab','playworld','quillix','roamly','synaptix','terranest','vendora','veyra','voxora']) {
        const snapshot = await ref.collection('workspaces').doc(appId).collection('items').get();
        if (!snapshot.empty) workspaces[appId] = snapshot.docs.map(doc => ({id:doc.id, ...doc.data()}));
      }
      return json(res,200,{uid, email:decoded.email || '', profile:profile.data() || {}, workspaces});
    }
    if (req.method === 'DELETE' && path === '/v1/me') {
      // Recent sign-in is required to avoid destructive actions from old stolen tokens.
      const age = Math.floor(Date.now()/1000) - (decoded.auth_time || 0);
      if (age > 300) return json(res,403,{error:'Reauthentication required before account deletion',code:'recent_login_required'});
      await db.recursiveDelete(ref);
      await getAuth().deleteUser(uid);
      return json(res,200,{ok:true});
    }
    return json(res,405,{error:'Method not allowed'});
  } catch (err) {
    const status = err.status || 500;
    console.error('Request failure:', err.message);
    return json(res,status,{error:status===500?'Internal server error':err.message});
  }
});
server.listen(port, '0.0.0.0', () => console.log(`MindHub API listening on ${port}`));
