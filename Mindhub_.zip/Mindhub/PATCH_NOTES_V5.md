# MindHub v5 patch notes

- Web account deletion errors now appear inside the deletion modal, in an accessible alert. Failed attempts keep the dialog open and permit retry; cancel dismisses it.
- Flutter account and verification-screen errors now strip the `Exception: ` wrapper using a shared `userFacingError` function.
- Firestore rules' `string.size()` semantics for supplementary Unicode symbols and combining marks remain **unverified** against the Firebase emulator. No claim of complete length parity is made.

## Emulator tests still required

Start a Firebase emulator using your Firebase project configuration, then create authenticated test contexts and attempt profile creates and updates with: (1) an Arabic name including combining diacritics, (2) an emoji string near 80 code points, and (3) an 81-code-point name. Compare rules decisions to Dart `runes.length` and JS `Array.from(name).length`. Do not rely on client-side checks as the security boundary.

## Status

Source-level patch only. Flutter compilation, browser interaction, live backend, and Firebase emulator checks were not performed in this environment.
