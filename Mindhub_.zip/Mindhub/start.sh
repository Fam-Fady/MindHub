#!/usr/bin/env bash
# Starts MindHub at http://localhost:3000  (needs Node.js 16+  ->  https://nodejs.org)
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Get it from https://nodejs.org and run this again."
  exit 1
fi
node server.js
