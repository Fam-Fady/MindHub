@echo off
REM Starts MindHub at http://localhost:3000  (needs Node.js 16+  ->  https://nodejs.org)
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Get it from https://nodejs.org and run this again.
  pause
  exit /b 1
)
start "" http://localhost:3000
node server.js
pause
