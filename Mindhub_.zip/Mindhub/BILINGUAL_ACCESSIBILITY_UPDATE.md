# MindHub bilingual and accessibility update (v9)

## Added in this source update
- Arabic and English remain the primary languages. The dashboard switches document language and direction (`lang` and `dir`) and passes the selected language to each mini-app URL.
- The AI assistant interface now localizes its accessible labels, input placeholder, send action, status text, and configuration/login errors in Arabic and English. The backend assistant prompt already instructs the model to reply in the user's language.
- Added a keyboard-visible skip link to the main content.
- Added an accessibility toolbar with normal, large and extra-large text; high-contrast mode; and reduced-motion mode. Preferences are saved locally and applied to the embedded same-origin mini-app when possible.
- Improved focus visibility, line spacing, and responsive wrapping for accessibility controls.
- Mirrored the updated web app into Flutter's bundled web assets and bumped the PWA cache version so browsers refresh the shell.

## Important limitations and remaining verification
- These changes are an accessibility improvement, **not proof of WCAG 2.2 AA compliance**. Every screen and mini-app still needs manual keyboard, screen-reader, zoom/reflow, contrast, touch-target, form-label, error-message, and media-caption testing with disabled users.
- Arabic translations must be reviewed by a fluent Arabic speaker, including all labels, validation messages, date/number formats, and text direction inside each of the 23 mini-apps.
- Accessibility preferences currently persist in the browser on each device; they are not yet part of the user's cloud profile.
- Captions/transcripts must be added to any audio/video content that lacks them.
- The AI assistant still requires the backend to be deployed and `AI_API_KEY` configured server-side, plus `MINDHUB_API_BASE_URL` in the web configuration. Never put the AI key in browser code.
- Firebase project configuration, hosting, Firestore rules deployment, signed Android/iOS builds, and store publication require the owner's accounts and credentials. This ZIP does not represent a deployed service or published mobile apps.
- The existing whole-workspace cloud sync is last-write-wins; simultaneous edits across devices can overwrite each other. Conflict-aware sync, scheduled backups, restore drills, and export/import verification remain production tasks.

## Validation performed
- Node syntax checks passed for both inline dashboard scripts.
- The updated web files were mirrored to `flutter/assets/web`.
- The service-worker cache key was incremented to `mindhub-v9`.
