# MindHub synchronization status

The current source includes authenticated per-mini-app snapshot sync for all 23 HTML mini-apps through `/v1/workspaces/:appId`. Each app keeps local browser storage for offline use and attempts cloud restore/upload when a valid Firebase ID token and deployed API are available.

**Conflict policy:** latest snapshot wins at the whole mini-app level. This is suitable as an initial cross-device sync layer, not simultaneous collaborative editing. For important data, test with multiple devices and implement record-level conflict handling before production.

Cloud sync is not active until Firebase and the backend are configured and deployed. See `PLATFORM_UPGRADE.md`.
