# MindHub account/backend patch — 23 October 2026

## Code changes
- Flutter dashboard language toggle now sends `updatedAt: FieldValue.serverTimestamp()` in its merged profile write.
- HTML account page now has email-verification instructions, resend, reload/token-refresh, and avoids reading restricted profiles until verified. Signup creates the initial profile before sending verification.
- HTML account page now supports export (downloads JSON) and deletion (requires current password + reauthentication) for verified and unverified users. Configure `window.MINDHUB_API_BASE_URL` in `html/firebase-config.js`.
- Flutter verification page offers account export/view and password-confirmed deletion, via the configured backend.
- Backend removed shared remote-address throttling (which could aggregate Cloud Run users), retains a per-verified-ID-token UID per-instance limit, exempts GET /health; unverified users may call their own export and deletion endpoints.
- Backend PATCH rejects empty/whitespace-only display names. Firestore profile validation rejects empty names when provided.

## Checks performed
- `node --check backend/server.js`: passed.
- `node --check html/account.js`: passed.
- ZIP integrity validation: passed.
- `npm install --package-lock-only` timed out because npm package downloads were not available. No lockfile is claimed.

## Not yet tested or complete
- Firebase Firestore emulator security rules and integration tests have NOT been run.
- Flutter analyze/build and device QA have NOT been run (no Flutter/Android SDK installed).
- No configured Firebase project, deployed API, or compiled APK is included.
- All 23 HTML app storage backends remain local/browser storage, not cloud-synced.
- Rate limiting is per instance after Firebase token verification; install a distributed edge WAF/gateway for anonymous abuse and shared rate limiting. Health endpoints must be excluded from user quotas.
- Export covers Firestore profile + native workspace items, not individual HTML app localStorage, and is not a full Firebase Auth data export.

## Steps before deployment
1. On an online machine: `cd backend && npm install --package-lock-only --ignore-scripts`; commit the resulting `package-lock.json`; use `npm ci --omit=dev` for reproducible installation.
2. Create/configure a Firebase project and deploy the rules only after emulator testing.
3. Set Firebase configuration values and `window.MINDHUB_API_BASE_URL` for the HTML page; add the Flutter `MINDHUB_API_BASE_URL` build define.
4. Test signup, verify/resend/refresh, language toggle, Arabic display name, export/delete when unverified, and account deletion on an emulator and a staging deployment.
5. Deploy server behind suitable distributed rate limiting/WAF and monitoring; test Cloud Run routing and CORS.
