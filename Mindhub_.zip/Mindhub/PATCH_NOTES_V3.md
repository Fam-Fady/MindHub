# MindHub v3 patch notes

- Flutter sign-up and profile Save reject trimmed empty names and names longer than 80 characters before Firebase writes.
- Flutter API export/delete show short translated-friendly errors instead of printing raw JSON responses. Native network/other failures may still show platform messages.
- Web delete confirmation uses an HTML `<dialog>` with masked `type=password`, not `prompt()`.
- `html/OPEN-ME-FIRST.txt` distinguishes static file preview from HTTPS-required account operations.
- `SETUP.md` documents authorized Firebase hostnames, exact backend `ALLOWED_ORIGIN`, and Cloud Armor/load-balancer protection that **must be configured externally**.

## Not completed

No live Firebase project, remote Cloud Armor resource, production API, compiled APK, npm lockfile, emulator tests, or cloud sync for all 23 HTML apps is included.
