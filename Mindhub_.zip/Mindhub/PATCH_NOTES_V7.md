# MindHub v7 patch notes (competition package)

Fixed (all copies: html/, flutter/assets/web/, and the embedded sources inside MindHub-All-in-One.html):
- **Broken icon links** in MindHub-All-in-One.html (`icons/...` did not exist) replaced with inline icons.
- **PlayLab links broken in the single-file build**: the Games tile and the Offline Toolkit link now open the embedded PlayLab through a checked postMessage bridge; standalone use still opens `playlab.html`.
- **Offline Toolkit**: removed the missing `/manifest.webmanifest` link and the absolute `/apps/playlab.html` path.
- **Offline support was advertised but missing**: both pages registered `/service-worker.js`, which was not in the package. Added `service-worker.js` (network-first, cached copy when offline).
- **Android release build**: the generated project had no `INTERNET` permission in the main manifest and blocked cleartext traffic to the local `http://localhost:8087` asset server. The workflow now patches both, sets minSdk 23, deletes the generated `test/widget_test.dart` (it would fail `flutter analyze`), and no longer fails on analyzer warnings.
- Flutter README rewritten to match the real build flow (`--dart-define`, no `flutterfire configure`) and the current Firestore rules.

Checked and found fine: JS syntax of all 23 apps, hub, account page and API; JSON/YAML files; app IDs vs asset filenames; Dart bracket balance.

Not done (needs real services): Flutter compile, Firebase emulator tests, deployed API, APK. Mini-app data is still not synced to accounts.
