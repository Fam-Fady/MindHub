# MindHub v8 review fixes

Fixed:
- **Flutter SDK constraint**: `main.dart` uses `Color.withValues()` (Dart 3.6 / Flutter 3.27+), but `pubspec.yaml` allowed Dart 3.4. Constraint raised to `>=3.6.0`.
- **HTML tab could spin forever**: if the local asset server on port 8087 failed to start, the HTML tab showed an endless spinner. It now shows a message and a Retry button.
- **Verification screen overflow**: the email-verification column had no scrolling and could overflow on small or landscape screens. It is now scrollable.
- **Service-worker registration used absolute paths**: standalone `offline-toolkit.html` and the hub page now use relative paths, so they work when hosted in a sub-folder. (The copy embedded inside the single-file build keeps the root path because it runs from an embedded document.)
- **API deploy workflow**: now stops with a clear message if `MINDHUB_HTML_ORIGIN` is not set, instead of deploying an API whose CORS silently blocks the website.
- **Stale text**: Flutter `OPEN-ME-FIRST.txt` referred to a backend that is not part of the package; it now describes the real setup.
- Removed a redundant label expression in the Flutter app-page toggle.

Checked and found fine: JavaScript syntax of all 23 apps, hub, account page, service worker and API (77 inline scripts); embedded JSON blocks; YAML and JSON files; Dart bracket balance; html/ and flutter/assets/web/ copies identical except the intentionally different launcher files.

Not run (needs real services): Flutter compile, Firebase emulator tests, deployed API, APK build.
