# MindHub v4 focused fixes

1. Shared `apiError` is now a top-level Dart function, used by both the account screen and email-verification screen for failed export/deletion responses.
2. Web deletion uses the form `submit` event with `preventDefault()`, including Enter-key submission; the button is `type="submit"`. The dialog does not close until deletion succeeds.
3. Flutter validates display names using `displayName.runes.length` (Unicode code points), and browser/API JavaScript use `Array.from(displayName).length` / `[...displayName.trim()].length`. Firebase rules retain their `string.size()` check.

## Verification limits
JavaScript syntax checks and ZIP verification are performed locally. Flutter/Dart compilation, real browser form interactions, Firestore emulator, live Firebase/API, and APK have not been run here.
