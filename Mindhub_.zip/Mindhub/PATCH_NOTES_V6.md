# MindHub v6 targeted patches

- Flutter `main.dart`: workspace save, workspace delete, and profile save snackbars now use the shared `userFacingError(e)` formatter rather than printing raw exception objects.
- Web `account.js`: errors from the delete dialog are translated using Firebase `auth/*` codes and known API error conditions. Both English and Arabic have safe fallback messages, so raw SDK English messages are not shown in Arabic mode.

## Verification and limitations

- This is a source-only fix. Flutter SDK and Firebase emulator were not available for compilation/integration tests.
- Firebase name-length behavior remains unverified in the emulator.
- No Firebase project, live API, or APK is included.
