# MindHub platform upgrade — 2026-11-04

## Included in this source update
- Added a responsive, installable PWA manifest, theme metadata, app icon, and refreshed service-worker cache.
- Added an accessible floating MindHub AI chat panel to the web dashboard. It supports Arabic and English through the backend system prompt.
- Added authenticated `/v1/chat` backend proxy. The AI provider key remains server-side; configure `AI_API_KEY`, optionally `AI_API_URL` and `AI_MODEL`.
- Added authenticated per-mini-app workspace snapshot endpoints: `GET/PUT /v1/workspaces/:appId`.
- Added a browser-side cloud sync adapter to all 23 mini-app pages. It restores a newer cloud snapshot and uploads local changes when signed in and online. Offline changes remain local until connectivity returns.
- Updated Firestore rules to permit the bounded workspace state document while retaining owner-only access.
- Account page now keeps a refreshed Firebase ID token in same-origin localStorage for the dashboard and mini-app sync adapter.
- Mirrored updated web assets into the Flutter WebView bundle.

## Required setup before production
1. Configure `html/firebase-config.js` with a real Firebase web app config and deployed API URL.
2. Deploy the backend with Firebase Admin credentials and set `ALLOWED_ORIGIN` to the exact production origin.
3. Set `AI_API_KEY` as a server environment secret. Never put it in frontend files. Set `AI_MODEL` if needed.
4. Deploy `flutter/firestore.rules` to the Firebase project.
5. Host the website over HTTPS. PWA installation and service workers do not work from `file://`.
6. Build and test Android/iOS apps with the correct Firebase app registrations, signing keys, Apple developer account, and store metadata.
7. Test cloud sync with two signed-in devices, offline edits, simultaneous edits, account deletion, and restore/export before real users depend on it.

## Important limitations
- This is a source-code upgrade, not a live deployment. No Firebase credentials, AI key, hosting account, APK, iOS archive, or store submission is included.
- Snapshot sync is last-write-wins at the whole mini-app level, not a collaborative merge engine. Avoid simultaneous editing of the same mini-app on multiple devices until per-record conflict resolution is implemented.
- Cloud sync requires HTTPS, a configured backend, verified Firebase email, and a signed-in account. Offline use remains device-local until sync succeeds.
- PWA caching is best-effort; dynamic/authenticated data is not cached.
- AI availability and cost depend on the provider account and configured key.
